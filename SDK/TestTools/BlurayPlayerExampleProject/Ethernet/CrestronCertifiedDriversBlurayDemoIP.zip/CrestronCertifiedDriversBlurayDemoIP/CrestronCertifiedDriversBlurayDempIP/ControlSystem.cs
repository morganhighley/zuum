using System;
using System.Linq;
using Crestron.RAD.Common.Enums;
using Crestron.RAD.Common.Helpers;
using Crestron.RAD.Common.Interfaces;
using Crestron.SimplSharp;                          	// For Basic SIMPL# Classes
using Crestron.SimplSharp.CrestronIO;
using Crestron.SimplSharp.Reflection;
using Crestron.SimplSharpPro;                       	// For Basic SIMPL#Pro classes
using Crestron.SimplSharpPro.DeviceSupport; // For Generic Device Support
using Crestron.SimplSharpPro.UI;
using CrestronCertifiedDriversBlurayDempIP.Panel_Signals;

namespace CrestronCertifiedDriversBlurayDempIP
{
    public partial class ControlSystem : CrestronControlSystem
    {
        public ControlSystem()
            : base()
        { }

        public override void InitializeSystem()
        {
            try
            {
                CreatePanel(_panelIpId, _panelSgdFilename);
                CreateDriver(_driverFilename, _deviceComPortNumber);
            }
            catch (Exception e)
            {
                ErrorLog.Error("Error in InitializeSystem: {0}", e.Message);
            }
        }

        private void CreatePanel(uint ipId, string sgdFilename)
        {
            //Check OS and convert to proper path if needed

            string _sgdFilename = OsHelper.ConvertPathBasedOnOs(sgdFilename);
            _panel = new XpanelForSmartGraphics(ipId, this);
            _panel.LoadSmartObjects(_sgdFilename);
            _panel.SmartObjects[(uint)PanelSmartObjects.DPad].SigChange += new SmartObjectSigChangeEventHandler(BlurayPlayerDpadChange);
            _panel.SigChange += new SigEventHandler(PanelSigChange);
            _panel.Register();
        }

        private void CreateDriver(string filename, uint comPortNumber)
        {
            //Check OS and convert to proper path if needed
            string _filename = OsHelper.ConvertPathBasedOnOs(filename);
            // Use reflection to get the driver
            LoadPkgFile(_filename, 0, string.Empty, 0, false);
        }

        private void BlurayPlayerStateChange(BlurayPlayerStateObjects state, IBasicBlurayPlayer device, byte arg3)
        {
            switch (state)
            {
                case BlurayPlayerStateObjects.Connection:
                    _panel.StringInput[(uint)PanelSerialSignals.ConnectionFeedback].StringValue = device.Connected ? "Connected" : "Disconnected";
                    break;

                case BlurayPlayerStateObjects.Power:
                    _panel.StringInput[(uint)PanelSerialSignals.PowerFeedback].StringValue = device.PowerIsOn ? "On" : "Off";
                    break;
            }
        }

        private void SetDefaultValues()
        {
            if (_blurayDevice != null)
            {
                // Update manufacturer and model feedback
                _panel.StringInput[(uint)PanelSerialSignals.ManufacturerFeedback].StringValue = _blurayDevice.Manufacturer;
                _panel.StringInput[(uint)PanelSerialSignals.ModelFeedback].StringValue = _blurayDevice.BaseModel;

                // Update digital enable joins for all buttons
                _panel.BooleanInput[(uint)PanelDigitalSignals.Audio].BoolValue = _blurayDevice.SupportsAudio;
                _panel.BooleanInput[(uint)PanelDigitalSignals.Display].BoolValue = _blurayDevice.SupportsDisplay;
                _panel.BooleanInput[(uint)PanelDigitalSignals.Eject].BoolValue = _blurayDevice.SupportsEject;
                _panel.BooleanInput[(uint)PanelDigitalSignals.Options].BoolValue = _blurayDevice.SupportsOptions;
                _panel.BooleanInput[(uint)PanelDigitalSignals.Subtitle].BoolValue = _blurayDevice.SupportsSubtitle;
                _panel.BooleanInput[(uint)PanelDigitalSignals.ForwardScan].BoolValue = _blurayDevice.SupportsForwardScan;
                _panel.BooleanInput[(uint)PanelDigitalSignals.ForwardSkip].BoolValue = _blurayDevice.SupportsForwardSkip;
                _panel.BooleanInput[(uint)PanelDigitalSignals.Pause].BoolValue = _blurayDevice.SupportsPause;
                _panel.BooleanInput[(uint)PanelDigitalSignals.Play].BoolValue = _blurayDevice.SupportsPlay;
                _panel.BooleanInput[(uint)PanelDigitalSignals.PowerOff].BoolValue = _blurayDevice.SupportsDiscretePower;
                _panel.BooleanInput[(uint)PanelDigitalSignals.PowerOn].BoolValue = _blurayDevice.SupportsDiscretePower;
                _panel.BooleanInput[(uint)PanelDigitalSignals.PowerToggle].BoolValue = _blurayDevice.SupportsTogglePower;
                _panel.BooleanInput[(uint)PanelDigitalSignals.ReverseScan].BoolValue = _blurayDevice.SupportsReverseScan;
                _panel.BooleanInput[(uint)PanelDigitalSignals.ReverseSkip].BoolValue = _blurayDevice.SupportsReverseSkip;
                _panel.BooleanInput[(uint)PanelDigitalSignals.Stop].BoolValue = _blurayDevice.SupportsStop;
                _blurayDevice.EnableLogging = true;
            }
        }

        private void PanelSigChange(BasicTriList currentDevice, SigEventArgs args)
        {
            if (_blurayDevice == null)
            {
                return;
            }

            switch (args.Sig.Type)
            {
                case eSigType.Bool:
                    {
                        if (Enum.IsDefined(typeof(PanelDigitalSignals), (int)args.Sig.Number))
                        {
                            PanelDigitalSignals signalNumber = (PanelDigitalSignals)args.Sig.Number;
                            if (args.Sig.BoolValue)
                            {
                                switch (signalNumber)
                                {
                                    case PanelDigitalSignals.Audio:
                                        _blurayDevice.Audio();
                                        break;

                                    case PanelDigitalSignals.Display:
                                        _blurayDevice.Display();
                                        break;

                                    case PanelDigitalSignals.Eject:
                                        _blurayDevice.Eject();
                                        break;

                                    case PanelDigitalSignals.Options:
                                        _blurayDevice.Options();
                                        break;

                                    case PanelDigitalSignals.Subtitle:
                                        _blurayDevice.Subtitle();
                                        break;

                                    case PanelDigitalSignals.ForwardScan:
                                        _blurayDevice.ForwardScan();
                                        break;

                                    case PanelDigitalSignals.ForwardSkip:
                                        _blurayDevice.ForwardSkip();
                                        break;

                                    case PanelDigitalSignals.Pause:
                                        _blurayDevice.Pause();
                                        break;

                                    case PanelDigitalSignals.Play:
                                        _blurayDevice.Play();
                                        break;

                                    case PanelDigitalSignals.PowerOff:
                                        _blurayDevice.PowerOff();
                                        break;

                                    case PanelDigitalSignals.PowerOn:
                                        _blurayDevice.PowerOn();
                                        break;

                                    case PanelDigitalSignals.PowerToggle:
                                        _blurayDevice.PowerToggle();
                                        break;

                                    case PanelDigitalSignals.ReverseScan:
                                        _blurayDevice.ReverseScan();
                                        break;

                                    case PanelDigitalSignals.ReverseSkip:
                                        _blurayDevice.ReverseSkip();
                                        break;

                                    case PanelDigitalSignals.Stop:
                                        _blurayDevice.Stop();
                                        break;

                                }
                            }
                        }
                    }
                    break;
            }
        }
        private void BlurayPlayerDpadChange(GenericBase currentDevice, SmartObjectEventArgs args)
        {
            if (_blurayDevice != null)
            {
                if (args.Sig.BoolValue)
                {
                    switch (args.Sig.Number)
                    {
                        case 1:     // Up
                            _blurayDevice.ArrowKey(ArrowDirections.Up, CommandAction.Hold);
                            break;
                        case 2:     // Down
                            _blurayDevice.ArrowKey(ArrowDirections.Down, CommandAction.Hold);
                            break;
                        case 3:     // Left
                            _blurayDevice.ArrowKey(ArrowDirections.Left, CommandAction.Hold);
                            break;
                        case 4:     // Right
                            _blurayDevice.ArrowKey(ArrowDirections.Right, CommandAction.Hold);
                            break;
                        case 5:     // Center
                            _blurayDevice.Enter();
                            break;
                    }
                }
                else
                {
                    switch (args.Sig.Number)
                    {
                        case 1:     // Up
                            _blurayDevice.ArrowKey(ArrowDirections.Up, CommandAction.Release);
                            break;
                        case 2:     // Down
                            _blurayDevice.ArrowKey(ArrowDirections.Down, CommandAction.Release);
                            break;
                        case 3:     // Left
                            _blurayDevice.ArrowKey(ArrowDirections.Left, CommandAction.Release);
                            break;
                        case 4:     // Right
                            _blurayDevice.ArrowKey(ArrowDirections.Right, CommandAction.Release);
                            break;
                    }
                }
            }
        }

        private T GetAssembly<T>(string fileName, string deviceInterfaceName, string deviceTransportName)
        {

            if (string.IsNullOrEmpty(fileName) || string.IsNullOrEmpty(deviceInterfaceName) || string.IsNullOrEmpty(deviceTransportName))
            {
                return default(T);
            }
            var dll = Assembly.LoadFrom(fileName);
            var types = dll.GetTypes();
            foreach (var cType in types)
            {
                var interfaces = cType.GetInterfaces();
                if (interfaces.FirstOrDefault(x => x.Name == deviceInterfaceName) == null)
                {
                    continue;
                }
                if (interfaces.FirstOrDefault(x => x.Name == deviceTransportName) != null)
                {
                    return (T)dll.CreateInstance(cType.FullName);
                }
            }
            return default(T);
        }

        private static string CheckOSFilePath(string path)
        {
            string newPath = OsHelper.ConvertPathBasedOnOs(path);
            return newPath;
        }

        // Panel settings
        private readonly uint _panelIpId = 0x03;
        private readonly string _panelSgdFilename = CheckOSFilePath(Directory.GetApplicationDirectory() + "\\CCD BlurayPlayer Serial Example Project.sgd");
        // Driver settings
        private readonly byte _deviceId = 1;
        private readonly uint _deviceComPortNumber = 1;
        private readonly string _driverFilename = CheckOSFilePath(Directory.GetApplicationDirectory() + "\\BlurayPlayer_Oppo_UDP-203_Serial.pkg");
        private static readonly string _uniqueFileGuid = Guid.NewGuid().ToString();
        private readonly string _pkgUnzipDirectory = CheckOSFilePath(string.Format("{0}\\CrestronCertifiedDrivers\\BlurayPlayer_Oppo_UDP-203_Serial\\",
            Directory.GetApplicationDirectory()));
        private readonly string _pkgUnzipTempDirectoryTemplate = CheckOSFilePath(string.Format("{0}\\CrestronCertifiedDrivers\\BlurayPlayer_Oppo_UDP-203_Serial\\",
            Directory.GetApplicationDirectory()));
        private string _pkgUnzipTempDirectory;
        private static CCriticalSection _pkgCriticalSection = new CCriticalSection();

        // Driver and panel
        private XpanelForSmartGraphics _panel;
        private IBasicBlurayPlayer _blurayDevice;
    }
}