﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.RAD.Common.Enums;
using Crestron.RAD.Common.Interfaces;
using Crestron.RAD.ProTransports;
using Crestron.SimplSharp;
using Crestron.SimplSharp.CrestronIO;

namespace CrestronCertifiedDriversBlurayDempIP
{
    public partial class ControlSystem
    {
        private void DeletePkgTempDirectory(string directory)
        {
            try
            {
                if (Directory.Exists(directory))
                {
                    Directory.Delete(directory, true);
                }
            }
            catch
            { }
        }

        private void LoadPkgFile(string filename, int id, string ipAddress, int port, bool enableLogging)
        {
            if (File.Exists(filename) == false)
            {
                ErrorLog.Notice(string.Format("Driver - File specified ({0}) does not exist on the control system", filename));
                return;
            }
            //_pkgUnzipTempDirectory = string.Format("{0}\\{1}", _pkgUnzipTempDirectoryTemplate, Guid.NewGuid().ToString());
            _pkgUnzipTempDirectory = Path.Combine(_pkgUnzipTempDirectoryTemplate, Guid.NewGuid().ToString());
            string lowerCaseDriverFilename = string.Empty;
            string driverDllFilename = string.Empty;
            string driverIrFilename = string.Empty;
            string driverDllTempFilename = string.Empty;
            string driverIrTempFilename = string.Empty;
            string driverDatFileName = string.Empty;

            try
            {
                lowerCaseDriverFilename = Path.GetFileName(filename);
                driverDllFilename = Path.Combine(_pkgUnzipDirectory, Path.ChangeExtension(lowerCaseDriverFilename, ".dll"));
                driverIrFilename = Path.Combine(_pkgUnzipDirectory, Path.ChangeExtension(lowerCaseDriverFilename, ".ir"));
                driverDllTempFilename = Path.Combine(_pkgUnzipTempDirectory, Path.ChangeExtension(lowerCaseDriverFilename, ".dll"));
                driverIrTempFilename = Path.Combine(_pkgUnzipTempDirectory, Path.ChangeExtension(lowerCaseDriverFilename, ".ir"));
                driverDatFileName = Path.Combine(_pkgUnzipTempDirectory, Path.ChangeExtension(lowerCaseDriverFilename, ".dat"));
                CrestronConsole.PrintLine("\rDriver DLL FileName: {0}\tTemp FileName: {1}\r", driverDllFilename, driverDllTempFilename);
            }
            catch (ArgumentException)
            {
                ErrorLog.Notice(string.Format("Driver - Pkg file loading failed - invalid filename provided ({0})", filename));
                return;
            }

            bool isDllDriver = false;
            bool isIrDriver = false;

            try
            {
                _pkgCriticalSection.Enter();
                if (!Directory.Exists(_pkgUnzipDirectory))
                {
                    Directory.Create(_pkgUnzipDirectory);
                }
                if (!Directory.Exists(_pkgUnzipTempDirectory))
                {
                    Directory.Create(_pkgUnzipTempDirectory);
                }
                CrestronZIP.ResultCode unzipResultCode = CrestronZIP.ResultCode.ZR_FAILED;

                unzipResultCode = CrestronZIP.Unzip(filename, _pkgUnzipTempDirectory);
                if (unzipResultCode == CrestronZIP.ResultCode.ZR_OK)
                {
                    // Verify a valid PKG file was unzipped - should contain a .DAT file and .DLL/.IR file
                    if (!File.Exists(driverDatFileName) || (!File.Exists(driverDllTempFilename) && !File.Exists(driverIrTempFilename)))
                    {
                        ErrorLog.Notice("Driver - The PKG file is missing files");
                    }
                    else
                    {
                        isDllDriver = File.Exists(driverDllTempFilename);
                        isIrDriver = File.Exists(driverIrTempFilename);

                        // Compare extracted driver to any pre-existing ones with the same name
                        if (isDllDriver && File.Exists(driverDllFilename))
                        {
                            if (File.GetLastWriteTime(driverDllFilename) != File.GetLastWriteTime(driverDllTempFilename))
                            {
                                File.Delete(driverDllFilename);
                                File.Move(driverDllTempFilename, driverDllFilename);
                            }
                        }
                        else if (isIrDriver && File.Exists(driverIrFilename))
                        {
                            if (File.GetLastWriteTime(driverIrFilename) != File.GetLastWriteTime(driverIrTempFilename))
                            {
                                File.Delete(driverIrFilename);
                                File.Move(driverIrTempFilename, driverIrFilename);
                            }
                        }
                        else
                        {
                            if (isDllDriver)
                            {
                                File.Move(driverDllTempFilename, driverDllFilename);
                            }
                            else if (isIrDriver)
                            {
                                File.Delete(driverIrFilename);
                                File.Move(driverIrTempFilename, driverIrFilename);
                            }
                        }
                    }
                }
                else
                {
                    ErrorLog.Notice(string.Format("Driver - Error unzipping PKG file - Error={0}", unzipResultCode));
                }
            }
            catch (Exception e)
            {
                ErrorLog.Notice(string.Format("Driver - Error unzipping PKG file - Error={0}", e.Message));
            }
            finally
            {
                _pkgCriticalSection.Leave();
            }
            CrestronConsole.PrintLine("\rFull Path: {0}\r", driverDllFilename);
            _blurayDevice = GetAssembly<IBasicBlurayPlayer>(driverDllFilename, "IBasicBlurayPlayer", "ISerialComport");

            if (_blurayDevice != null)
            {
                // Set up hardware
                ComPorts[_deviceComPortNumber].Register();
                var serialTransport = new SerialTransport(ComPorts[_deviceComPortNumber]);
                var serialDriver = _blurayDevice as ISerialComport;
                serialTransport.SetComPortSpec(serialDriver.ComSpec);

                // Initialize the transport
                serialDriver.Initialize(serialTransport);

                // Suscribe to events
                _blurayDevice.StateChangeEvent +=
                    new Action<BlurayPlayerStateObjects, IBasicBlurayPlayer, byte>(BlurayPlayerStateChange);

                // Set all default values for the VT Pro project
                SetDefaultValues();

                // Set the device ID
                _blurayDevice.Id = _deviceId;

                // Connect the driver to the device
                _blurayDevice.Connect();
            }
        }
    }
}