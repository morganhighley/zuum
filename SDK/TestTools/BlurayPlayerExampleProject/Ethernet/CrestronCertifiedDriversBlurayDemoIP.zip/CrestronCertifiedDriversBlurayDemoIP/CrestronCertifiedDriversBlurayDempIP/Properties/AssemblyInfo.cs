﻿using System.Reflection;

[assembly: AssemblyTitle("CrestronCertifiedDriversBlurayDempIP")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("CrestronCertifiedDriversBlurayDempIP")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyVersion("1.0.0.*")]

